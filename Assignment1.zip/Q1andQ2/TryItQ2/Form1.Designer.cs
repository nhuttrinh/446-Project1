﻿namespace TryItQ2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lowText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.upText = new System.Windows.Forms.TextBox();
            this.genBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.guessText = new System.Windows.Forms.TextBox();
            this.playBtn = new System.Windows.Forms.Button();
            this.attLabel = new System.Windows.Forms.Label();
            this.numLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lowText
            // 
            this.lowText.Location = new System.Drawing.Point(107, 87);
            this.lowText.Name = "lowText";
            this.lowText.Size = new System.Drawing.Size(100, 20);
            this.lowText.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Lower Limit";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(213, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = " Upper Limit";
            // 
            // upText
            // 
            this.upText.Location = new System.Drawing.Point(282, 87);
            this.upText.Name = "upText";
            this.upText.Size = new System.Drawing.Size(100, 20);
            this.upText.TabIndex = 3;
            // 
            // genBtn
            // 
            this.genBtn.Location = new System.Drawing.Point(406, 84);
            this.genBtn.Name = "genBtn";
            this.genBtn.Size = new System.Drawing.Size(168, 23);
            this.genBtn.TabIndex = 4;
            this.genBtn.Text = "Generate a Secret Number";
            this.genBtn.UseVisualStyleBackColor = true;
            this.genBtn.Click += new System.EventHandler(this.genBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Make a Guess";
            // 
            // guessText
            // 
            this.guessText.Location = new System.Drawing.Point(123, 117);
            this.guessText.Name = "guessText";
            this.guessText.Size = new System.Drawing.Size(100, 20);
            this.guessText.TabIndex = 6;
            // 
            // playBtn
            // 
            this.playBtn.Location = new System.Drawing.Point(249, 115);
            this.playBtn.Name = "playBtn";
            this.playBtn.Size = new System.Drawing.Size(75, 23);
            this.playBtn.TabIndex = 7;
            this.playBtn.Text = "Play";
            this.playBtn.UseVisualStyleBackColor = true;
            this.playBtn.Click += new System.EventHandler(this.playBtn_Click);
            // 
            // attLabel
            // 
            this.attLabel.AutoSize = true;
            this.attLabel.Location = new System.Drawing.Point(345, 124);
            this.attLabel.Name = "attLabel";
            this.attLabel.Size = new System.Drawing.Size(48, 13);
            this.attLabel.TabIndex = 8;
            this.attLabel.Text = "Attempts";
            // 
            // numLabel
            // 
            this.numLabel.AutoSize = true;
            this.numLabel.Location = new System.Drawing.Point(436, 124);
            this.numLabel.Name = "numLabel";
            this.numLabel.Size = new System.Drawing.Size(77, 13);
            this.numLabel.TabIndex = 9;
            this.numLabel.Text = " The number is";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numLabel);
            this.Controls.Add(this.attLabel);
            this.Controls.Add(this.playBtn);
            this.Controls.Add(this.guessText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.genBtn);
            this.Controls.Add(this.upText);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lowText);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox lowText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox upText;
        private System.Windows.Forms.Button genBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox guessText;
        private System.Windows.Forms.Button playBtn;
        private System.Windows.Forms.Label attLabel;
        private System.Windows.Forms.Label numLabel;
    }
}

