﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace WcfClientConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            int secretNum;// Secret number.
            int guessNum;// Guess number.
            
            string exit = ""; //Exit flag.
            string again = ""; // Again flag.

            // (1) Create a proxy to the WCF service.
            myInterfaceClient myPxy = new myInterfaceClient();
            // (2) Call the service operations through the proxy
            do
            {
                int count = 0;// Attempts number.
                string message = "";// Message of guessing a number.
                Console.WriteLine("Enter Lower Limit: "); //Prompt user to input lower limit.
                int lower = Convert.ToInt16(Console.ReadLine());//Store lower limit.
                Console.WriteLine("Enter Upper Limit: ");//Prompt user to input upper limit.
                int upper = Convert.ToInt16(Console.ReadLine());//Store upper limit.

                secretNum = myPxy.SecretNumber(lower, upper); //Call SecretNumber operation.
                while (message != "correct")
                {
                    Console.WriteLine("Enter Your Guess Number: "); //Prompt user to input guess number.
                    guessNum = Convert.ToInt16(Console.ReadLine());
                    message = myPxy.checkNumber(guessNum, secretNum); //Call checkNumber operation.
                    count++; // Increment the attempts.
                    Console.WriteLine("Attempts: {0}", count);//Display the attempts
                    Console.WriteLine("This number is {0}", message);

                    Console.WriteLine("Want to exit? (Y/N): "); //ASk user if want to continue to guess.
                    exit = Console.ReadLine();
                    if (exit == "Y" || exit == "y") // If yes then close the console.
                    {
                        myPxy.Close(); // Close the proxy.
                        Environment.Exit(0);
                    }
                    
                }
                Console.WriteLine("Want to play again? (Y/N): ");
                again = Console.ReadLine();
            } while (again == "Y" || again == "y");

            // (3) Close the proxy, the channel to the service.
            myPxy.Close();


        }
    }
}
