﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TryItQ2
{
    public partial class Form1 : Form
    {
        static int result; // secret number
        static int count = 0;// Attempts
        public Form1()
        {
            InitializeComponent();
        }

        private void genBtn_Click(object sender, EventArgs e)
        {
            count = 0; // initialize the value of count
            NumGuessRef.Service1Client secretNum = new NumGuessRef.Service1Client(); // Create a proxy to the WCF serrvice.
            int lower = Convert.ToInt16(lowText.Text); //Read and convert lower input to integer.
            int upper = Convert.ToInt16(upText.Text); //Read and convert upper input to integer.

            result = secretNum.SecretNumber(lower, upper); // Call the .service operation through the proxy
        }

        private void playBtn_Click(object sender, EventArgs e)
        {
            count++;
            NumGuessRef.Service1Client secretNum = new NumGuessRef.Service1Client();// Create a proxy to the WCF serrvice.
            int guessNum = Convert.ToInt16(guessText.Text);//Read and convert guessing number input to integer.
            numLabel.Text = "The number is: " + secretNum.checkNumber(guessNum, result); // Display the result from the .service operation through the proxy.
            attLabel.Text = "Attempt: " + Convert.ToString(count);// Display the attempts.
        }
    }
}
